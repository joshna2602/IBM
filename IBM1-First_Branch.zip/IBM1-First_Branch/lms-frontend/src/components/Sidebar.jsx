import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div className="w-60 h-screen bg-gray-100 p-4">
      <h2 className="text-xl font-bold mb-4">Admin Panel</h2>
      <ul className="space-y-2">
        <li><Link to="/">Dashboard</Link></li>
        <li><Link to="/courses">Courses</Link></li>
        <li><Link to="/students">Students</Link></li>
        <li><Link to="/enroll">Enroll</Link></li>
      </ul>
    </div>
  );
}
