export default function Enroll() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Enroll Student</h1>

      <select>
        <option>Alice</option>
        <option>Bob</option>
      </select>

      <select>
        <option>Intro to HTML</option>
        <option>CSS Basics</option>
      </select>

      <button>Enroll</button>
    </div>
  );
}
