import { useEffect, useState } from "react";
import API from "../services/api";

export default function Students() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState("");

  const fetchStudents = async () => {
    const res = await API.get("/students");
    setStudents(res.data);
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const addStudent = async () => {
    if (!name) return alert("Enter student name");

    await API.post("/students", { name });
    setName("");
    fetchStudents(); 
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Students</h1>

      <div className="mb-4">
        <input
          className="border p-2 mr-2"
          placeholder="Student Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button
          className="bg-blue-500 text-white px-4 py-2"
          onClick={addStudent}
        >
          Add
        </button>
      </div>

      <ul>
        {students.map((s) => (
          <li key={s._id}>{s.name}</li>
        ))}
      </ul>
    </div>
  );
}
