export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p>Total Courses: 0</p>
      <p>Total Students: 0</p>
    </div>
  );
}
