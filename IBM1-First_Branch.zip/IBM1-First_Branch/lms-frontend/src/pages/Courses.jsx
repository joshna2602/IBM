export default function Courses() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Courses</h1>
      <ul>
        <li>Intro to HTML</li>
        <li>CSS Basics</li>
        <li>JavaScript Fundamentals</li>
      </ul>
    </div>
  );
}
